# Pool Trajectory — Android starter

Projeto Android nativo em Kotlin para uma calculadora manual de trajetória de bilhar, com visualização simples da direção da tacada. Funciona offline e não se conecta ao 8 Ball Pool, não lê a tela do jogo e não modifica a memória do processo.

## Gerar APK pelo GitHub Actions

1. Crie um repositório no GitHub e envie todos os arquivos desta pasta.
2. Abra a aba **Actions**.
3. O workflow **Build Android APK** executa em cada push/PR e também pode ser iniciado em **Run workflow**.
4. Abra a execução concluída e baixe o artefato `pool-trajectory-debug-apk`.
5. Dentro do ZIP do artefato estará `app-debug.apk`.

## Compilar localmente

Requisitos: JDK 17 e Gradle 8.9 instalados.

```bash
gradle assembleDebug
```

O APK de depuração ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Limitações

- A linha é uma estimativa geométrica, não uma simulação precisa da física do jogo.
- Não detecta bolas automaticamente, não calcula colisões reais e não inclui mira sobreposta ao jogo.
- Para distribuição pública, configure assinatura de release e revise o `targetSdk` conforme as exigências atuais da Play Store.
