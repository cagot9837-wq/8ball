package com.example.pooltrajectory

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.PI

class MainActivity : Activity() {
    private lateinit var distanceInput: EditText
    private lateinit var angleInput: EditText
    private lateinit var result: TextView
    private lateinit var table: TableView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(Color.rgb(15, 35, 31))
        }

        val title = TextView(this).apply {
            text = "Pool Trajectory"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        content.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "Calculadora manual de trajetória — funciona offline"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(14))
        }
        content.addView(subtitle, matchWrap())

        distanceInput = field("Distância até a bola (1–100)")
        angleInput = field("Ângulo da tacada em graus (0–359)")
        content.addView(distanceInput, matchWrap())
        content.addView(angleInput, matchWrap())

        val calculate = Button(this).apply {
            text = "Calcular trajetória"
            setOnClickListener { calculateTrajectory() }
        }
        content.addView(calculate, matchWrap())

        table = TableView()
        content.addView(table, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        result = TextView(this).apply {
            text = "Insira a distância e o ângulo para ver uma estimativa."
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(0, dp(12), 0, 0)
        }
        content.addView(result, matchWrap())

        val note = TextView(this).apply {
            text = "Uso como calculadora independente. Não lê nem altera o jogo; o desenho é uma estimativa e não inclui física exata de colisões."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(10), 0, 0)
        }
        content.addView(note, matchWrap())

        setContentView(content)
    }

    private fun field(hintText: String) = EditText(this).apply {
        hint = hintText
        setHintTextColor(Color.GRAY)
        setTextColor(Color.WHITE)
        textSize = 16f
        singleLine = true
        inputType = android.text.InputType.TYPE_CLASS_NUMBER or
            android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or
            android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
        setPadding(dp(12), dp(8), dp(12), dp(8))
    }

    private fun calculateTrajectory() {
        val distance = distanceInput.text.toString().toFloatOrNull()
        val angle = angleInput.text.toString().toFloatOrNull()
        if (distance == null || angle == null || distance !in 1f..100f || angle !in 0f..359f) {
            result.text = "Valores inválidos. Distância: 1–100; ângulo: 0–359."
            return
        }
        table.distance = distance / 100f
        table.angleDegrees = angle
        table.invalidate()

        val rad = angle * PI / 180.0
        val dx = distance * cos(rad)
        val dy = distance * sin(rad)
        result.text = "Deslocamento estimado: X = %.1f, Y = %.1f\nÂngulo: %.1f°".format(dx, dy, angle)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private inner class TableView : View(this@MainActivity) {
        var distance = 0.65f
        var angleDegrees = 25f
        private val felt = Paint(Paint.ANTI_ALIAS_FLAG)
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 225, 100)
            strokeWidth = dp(3).toFloat()
            style = Paint.Style.STROKE
        }
        private val ball = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        private val pocket = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(8, 15, 13) }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val pad = dp(18).toFloat()
            val left = pad
            val top = pad
            val right = width - pad
            val bottom = height - pad
            felt.color = Color.rgb(22, 112, 75)
            canvas.drawRoundRect(left, top, right, bottom, dp(14).toFloat(), dp(14).toFloat(), felt)

            val pocketR = dp(8).toFloat()
            val corners = arrayOf(
                left to top, (left + right) / 2 to top, right to top,
                left to bottom, (left + right) / 2 to bottom, right to bottom
            )
            corners.forEach { canvas.drawCircle(it.first, it.second, pocketR, pocket) }

            val startX = left + (right - left) * 0.25f
            val startY = top + (bottom - top) * 0.65f
            val length = (right - left) * distance.coerceIn(0.05f, 1f) * 0.8f
            val rad = angleDegrees * PI / 180.0
            val endX = (startX + cos(rad).toFloat() * length).coerceIn(left + pocketR, right - pocketR)
            val endY = (startY - sin(rad).toFloat() * length).coerceIn(top + pocketR, bottom - pocketR)
            canvas.drawLine(startX, startY, endX, endY, line)
            canvas.drawCircle(startX, startY, dp(7).toFloat(), ball)
            felt.color = Color.rgb(245, 190, 50)
            canvas.drawCircle(endX, endY, dp(6).toFloat(), felt)
        }
    }
}
